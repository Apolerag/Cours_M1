fichier a regarder:
Sign.java
Verify.java
exo2.java
Main.java