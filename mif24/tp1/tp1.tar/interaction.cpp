#include "interaction.h"

Interaction::Interaction(const Experience* experience, const Resultat* resultat, int motiv): m_experience(experience),
    m_resultat(resultat), m_motiv(motiv)
{
}

Interaction::Interaction(const Interaction & i): m_experience(i.m_experience),
    m_resultat(i.m_resultat), m_motiv(i.motivation())
{
}

int Interaction::motivation() const
{
    return m_motiv;
}

void Interaction::setMotivation(int val)
{
    m_motiv = val;
}

const Experience& Interaction::experience() const
{
    return *m_experience;
}

const Resultat& Interaction::resultat() const
{
    return *m_resultat;
}

void Interaction::affichage() const
{
    qDebug()<<"Experience: "<<m_experience->num()<<"Resultat: "<<m_resultat->num()<<"Motivation: "<<m_motiv;
}

bool Interaction::operator <(const Interaction& i) const
{
    return motivation() < i .motivation();
}

bool Interaction::operator ==(const Interaction& i) const
{
    return (experience() == i.experience()) &&
            (resultat() == i.resultat()) &&
            (motivation() == i.motivation());
}

Interaction& Interaction::operator = (const Interaction& i)
{
    m_experience = i.m_experience;
    m_resultat = i.m_resultat;
    m_motiv = i.motivation();
    return *this;
}

uint qHash(const Interaction& i)
{
    return i.motivation();
}
